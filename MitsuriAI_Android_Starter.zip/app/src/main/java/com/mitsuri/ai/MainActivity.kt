package com.mitsuri.ai

import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MitsuriApp() }
    }
}

@Composable
fun MitsuriApp() {
    var text by remember { mutableStateOf("") }
    var reply by remember { mutableStateOf("Hiii! Main Mitsuri AI hoon 💗\nMujhse kuch bhi poochho.") }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val heard = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!heard.isNullOrBlank()) {
            text = heard
            reply = "Tumne kaha: $heard\n\nAI backend connect karne ke baad main iska intelligent answer dungi."
        }
    }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(null) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(20.dp))
                Box(
                    Modifier.size(150.dp).background(Color(0xFFFFC1D9), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🩷", style = MaterialTheme.typography.displayLarge)
                }
                Spacer(Modifier.height(14.dp))
                Text("Mitsuri AI", style = MaterialTheme.typography.headlineMedium)
                Text("Personal multilingual assistant", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(20.dp))

                Card(Modifier.fillMaxWidth()) {
                    Text(reply, Modifier.padding(18.dp))
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Mitsuri se baat karo") }
                )
                Spacer(Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        val intent = RecognizerIntent().apply {
                            action = RecognizerIntent.ACTION_RECOGNIZE_SPEECH
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        }
                        speechLauncher.launch(intent)
                    }) { Text("🎙️ Bolo") }

                    Button(onClick = {
                        tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "mitsuri_reply")
                    }) { Text("🔊 Suno") }
                }

                Spacer(Modifier.height(18.dp))
                Text(
                    "Next modules: secure AI backend, automatic language detection, reminders, home-screen widget, and anime avatar.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
